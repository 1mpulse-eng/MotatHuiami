@tool
extends Node2D
class_name TentacleVisual

## ============================================================================
## ШАБЛОН СЕГМЕНТНОГО ЩУПАЛЬЦА — куда положить свои спрайты:
##
## 1) Tentacle/TentacleVisual/SegmentTemplate/Body   (Sprite2D)  -> текстура сегмента тела
## 2) Tentacle/TentacleVisual/SegmentTemplate/Hinge  (Sprite2D)  -> текстура шарнира-заглушки
## 3) Tentacle/TentacleVisual/Tip (AnimatedSprite2D) -> создай SpriteFrames с анимациями:
##       "idle"  - зациклена, пока щупальце в покое
##       "reach" - зациклена/статична, пока щупальце вытянуто к цели
##       "grab"  - одноразовая (Loop выключен), проигрывается при подборе/вырывании
##       "throw" - одноразовая (Loop выключен), проигрывается при броске
##    Если каких-то анимаций ещё нет — код сам откатится на цветовую вспышку (см. flash_color),
##    так что шаблон работает и с частично готовым артом.
##
## Больше НИЧЕГО в коде трогать не нужно — SegmentTemplate дублируется в пул автоматически,
## текстуры/кадры оттуда копируются на все дубликаты сами. ИСПРАВЛЕНО: теперь копируется и
## СОБСТВЕННЫЙ scale, который ты выставил на Body/Hinge/Tip в редакторе (раньше код тупо
## перезаписывал его как Vector2.ONE * visual_scale и стирал твои относительные пропорции
## между Body и Hinge, если они у тебя различались).
## ============================================================================

## Сколько сегментов максимум в пуле. Должно с запасом покрывать max_reach при реальном
## размере текстуры Body — если увеличишь текстуру или visual_scale и щупальце перестанет
## дотягиваться до края зоны захвата (max_reach), подними это число.
@export var pool_size: int = 18
## УДАЛЕНО: раньше тут был ручной параметр segment_length, который ДОЛЖЕН был совпадать
## с реальной высотой текстуры Body, но ничего не мешало ему разойтись с фактом (так и
## произошло: было 16 при текстуре 32px) — из-за этого шаг между сегментами был в 2 раза
## меньше настоящего размера спрайта, и сегменты налезали друг на друга ПРИ ЛЮБОМ
## segment_overlap. Теперь шаг всегда берётся напрямую из текстуры (см. _get_segment_step),
## так что рассинхронизация в принципе невозможна.
## Насколько сильно соседние сегменты перекрывают друг друга (0.0 = встык по реальному
## размеру текстуры, 0.3 = каждый следующий заходит на 30% предыдущего).
## ИСПРАВЛЕНО: было 0.0, из-за чего при overlap=0 общая длина дуги = idle_segment_count
## сегментов ВПРИТЫК полным размером текстуры — щупальце физически растягивалось в разы
## длиннее самого персонажа. Поднято до 0.25 — сегменты плотнее наезжают друг на друга,
## общая длина дуги короче при том же количестве сегментов (и том же качестве кривой).
## Держи повыше (0.2–0.35), если нужна компактность; держи 0, только если специально хочешь
## максимально длинное щупальце и швы всё равно закрываются шарнирами (см. ниже).
@export_range(0.0, 0.6) var segment_overlap: float = 0.25
## Общий масштаб всего щупальца (сегменты, шарниры, кончик) — один рычаг, чтобы уменьшить/
## увеличить ВСЁ разом, не трогая отдельные числа. 1.0 = как нарисовано, 0.5 = в 2 раза меньше.
## ВАЖНО: применяется теперь поверх СОБСТВЕННОГО scale, заданного на Body/Hinge/Tip в
## редакторе (см. _body_base_scale/_hinge_base_scale), а не вместо него. Для Tip (единичный
## узел, без пары для сохранения пропорции) visual_scale применяется напрямую, как и раньше.
@export var visual_scale: float = 0.65
## Максимальная длина вытяжения. ДОЛЖНА совпадать с радиусом CircleShape2D зоны щупальца
## (Tentacle/Zone/CollisionShape2D в player.tscn, сейчас radius = 137.5101) — раньше тут стояло
## 110, из-за чего щупальце визуально не дотягивалось до цели на краю своей же зоны захвата.
@export var max_reach: float = 137.5101
## Поворотная поправка спрайта сегмента: 0, если на арте "верх" текстуры = направление
## наружу (от базы к кончику). Если твой арт нарисован по-другому — крути это число.
@export var segment_rotation_offset: float = PI / 2
## Разворот ВСЕЙ позы покоя целиком (радианы) — если щупальце огибает не ту сторону
## игрока, крути это одно число, не трогая градусы дуги ниже.
@export var idle_base_direction_offset: float = 0.0
## Из скольки сегментов состоит поза покоя. ИСПРАВЛЕНО ЕЩЁ РАЗ: 11 всё ещё давало общую длину
## дуги (count * шаг между сегментами) в несколько раз больше самого персонажа — щупальце
## визуально "убегало" далеко за спину/над головой вместо компактного крюка у плеча. Опущено
## до 7. Если после подбора текстур дуга всё ещё кажется длинной/короткой — крути в первую
## очередь ЭТО число (прямо пропорционально общей длине) и segment_overlap (см. ниже), а не
## visual_scale — тот масштабирует толщину сегментов вместе с длиной и легче промахнуться.
## ВАЖНО: реальное число ВИДИМЫХ сегментов в позе покоя теперь на 1 меньше этого числа —
## второй по счёту сегмент дуги (индекс 1) намеренно выбрасывается из цепочки в
## _build_curl_angles (см. ниже), при этом start/end углы и сама кривизна дуги не меняются.
@export var idle_segment_count: int = 7
## Экранный угол ПЕРВОГО сегмента (у тела), в градусах. 90° = вниз, 0° = вправо, -90° = вверх,
## 180° = влево. 0° = строго перпендикулярно корпусу (горизонтально) — первый сегмент ложится
## вплотную к телу без зазора/скоса, а не торчит наискось.
@export var idle_curl_start_deg: float = 0.0
## Экранный угол ПОСЛЕДНЕГО сегмента (у кончика), в градусах.
## ИСПРАВЛЕНО (было -190.0, из-за чего дуга получалась почти в 190° — БОЛЬШЕ полукруга).
## С линейной интерполяцией угла (см. _build_curl_angles) дуга — это отрезок ОКРУЖНОСТИ:
## при развороте больше 180° кончик заворачивается обратно ЗА линию старта и разность
## между кончиком и телом визуально пропадает — вся конструкция читается как замкнутое
## кольцо ("бублик") позади персонажа, а не как щупальце, огибающее его справа.
## Теперь дуга — 100° (0° -> -100°), заметно меньше полукруга. -130° (прошлое значение)
## всё ещё уводило щупальце слишком далеко вверх-назад за голову — вместе с длинной дугой
## (см. idle_segment_count/segment_overlap) это и читалось как "щупальце убегает далеко
## назад", а не компактный крюк у плеча. -100° = чуть выше строго вверх — кончик закручивается
## над точкой крепления, но по-прежнему рядом с силуэтом персонажа, а не за его пределами.
## Держи |start - end| заметно меньше 180, если не хочешь снова получить "бублик".
## ВАЖНО: этот угол по-прежнему задаёт форму ВСЕЙ кривой (используется в интерполяции для
## каждой точки дуги, см. _build_curl_angles), но САМ последний видимый сегмент теперь на
## этот угол не садится жёстко — см. idle_last_segment_curl_t ниже, он "недокручен" в сторону
## start_deg, т.е. развёрнут чуть наружу относительно этой цифры.
@export var idle_curl_end_deg: float = -100.0
## НОВОЕ: степень неравномерности кривизны дуги покоя (ease-in по параметру t).
## 1.0 = старое поведение (равномерная кривизна = дуга ИДЕАЛЬНОЙ окружности — та самая
## "геометрическая", бубликовая кривизна). Больше 1.0 = у основания щупальце разворачивается
## медленнее (идёт почти прямо от тела), а весь изгиб концентрируется ближе к кончику —
## силуэт получается как у настоящего гибкого отростка/хлыста (прямой стебель + закрученный
## кончик), а не как ровный сегмент окружности. Держи в районе 1.4–2.2.
@export_range(0.5, 4.0) var idle_curl_curve: float = 1.7
## НОВОЕ: насколько последний (видимый) сегмент дуги покоя доворачивается до idle_curl_end_deg.
## 1.0 = садится ровно на idle_curl_end_deg, как было раньше (максимально закручен внутрь).
## 0.0 = садится ровно на idle_curl_start_deg (полностью выпрямлен, "смотрит" туда же, куда и
## первый сегмент). Значение по умолчанию — компромисс: кончик развёрнут заметно НАРУЖУ
## относительно прежнего сильно закрученного положения, но изгиб всей дуги перед ним
## (см. idle_curl_curve/idle_curl_end_deg) не меняется — форма первых сегментов та же самая,
## доворачивается только последний.
@export_range(0.0, 1.0) var idle_last_segment_curl_t: float = 0.88

## Амплитуда лёгкого "виляния" цепочки при вытяжении к цели — угасает по мере приближения
## к 100% вытяжения (при extension=1 сегменты идут идеально прямо к цели).
@export var reach_wiggle_amplitude: float = 0.15
## Амплитуда органического шума (радианы) на позы покоя — не периодического, в отличие от sin.
@export var idle_jitter_amplitude: float = 0.05
@export var idle_jitter_speed: float = 0.7
## Через сколько секунд (случайно, в этом диапазоне) щупальце само сменит позу покоя —
## перескочит с правой стороны на зеркальную левую (или обратно), см. _pick_new_idle_pose.
@export var idle_pose_change_min: float = 4.0
@export var idle_pose_change_max: float = 9.0
@export var idle_pose_blend_duration: float = 1.6

# Цвета — используются только как запасной вариант (см. flash_color), пока на Tip
# не готовы анимации grab/throw. Как только анимации появятся, код сам их предпочтёт.
const COLOR_IDLE = Color(0.6, 0.15, 0.55)
const COLOR_RIP = Color(0.9, 0.15, 0.15)
const COLOR_PICKUP = Color(0.6, 0.15, 0.55)
const COLOR_THROW = Color(0.85, 0.7, 0.2)

# Поза покоя описывается всего двумя числами — текущими "живыми" версиями
# idle_curl_start_deg/idle_curl_end_deg (см. _current_start_deg/_current_end_deg ниже).
# Зеркалирование право<->лево — это не отдельный набор углов, а просто другая пара чисел:
# mirrored_start = 180 - start, mirrored_end = 180 - end (отражение по вертикали в экранных
# градусах). Переход между сторонами — это ПРЯМОЙ твин этих двух чисел (см. _pick_new_idle_pose),
# поэтому вся дуга целиком синхронно проходит через общую промежуточную форму (все сегменты
# одновременно смотрят в одну сторону на середине перехода), без излома посередине — раньше
# каждый сегмент лерпился по отдельности (lerp_angle) и мог "довернуть" в свою сторону/момент.
var _current_start_deg: float = 0.0
var _current_end_deg: float = 0.0
var _mirrored: bool = false
var _current_angles: Array = []

var _time: float = 0.0
var _extension: float = 0.0                # 0..1, текущая степень вытяжения к цели
var _target_local: Vector2 = Vector2.ZERO  # цель в локальных координатах узла

var _pose_timer: float = 0.0
var _next_pose_change: float = 0.0

## Небольшая угловая добавка к позе покоя, которая "звенит" затухающим колебанием сразу
## после retract() — имитирует инерцию: щупальце не останавливается мгновенно, а слегка
## доразворачивается и оседает, как настоящий гибкий отросток. См. _play_settle_wobble().
var _settle_wobble: float = 0.0

var _noise := FastNoiseLite.new()

var _pool_segments: Array = []
var _pool_bodies: Array = []
var _pool_hinges: Array = []

# ИСПРАВЛЕНО: раньше scale на дубликатах Body/Hinge жёстко ставился как
# Vector2.ONE * visual_scale, что стирало собственный относительный scale, заданный
# художником между Body и Hinge в редакторе (если он у них различался). Теперь этот исходный
# scale считывается один раз и используется как множитель — так visual_scale масштабирует
# ОБА разом, но их пропорция друг относительно друга сохраняется.
# ВАЖНО: для Tip (см. ниже) так делать НЕ нужно — это единичный узел, а не пара, между
# которыми есть пропорция, которую нужно сохранять. В прошлой правке я по ошибке завёл
# такой же _tip_base_scale и умножил его на visual_scale — если у Tip в редакторе уже стоял
# небольшой собственный scale, это давало ДВОЙНОЕ уменьшение (base_scale * visual_scale
# вместо просто visual_scale) — отсюда и "кончик стал очень маленьким". Убрано.
var _body_base_scale: Vector2 = Vector2.ONE
var _hinge_base_scale: Vector2 = Vector2.ONE

# ИСПРАВЛЕНО: ссылки на твины, чтобы убивать предыдущий твин перед созданием нового.
# Раньше reach_to/retract/_blend_to_pose/_play_settle_wobble/_play_tip_anticipation/
# flash_color каждый раз создавали НОВЫЙ Tween, не трогая предыдущий — при быстром повторном
# вызове (например, спам ЛКМ по броску/подбору) несколько твинов одновременно тянули одно и
# то же поле в разные стороны, и щупальце могло дёргаться/дрожать.
var _extension_tween: Tween
var _pose_tween: Tween
var _wobble_tween: Tween
var _anticipation_tween: Tween
var _flash_tween: Tween

@onready var segment_pool: Node2D = $SegmentPool
@onready var segment_template: Node2D = $SegmentTemplate
@onready var tip: AnimatedSprite2D = $Tip
@onready var weapon_sprite: Sprite2D = $Tip/WeaponSprite

func _ready():
	_noise.seed = randi()
	_noise.frequency = 0.15

	# Считываем исходные пропорции Body/Hinge ДО того, как что-либо перезапишет их scale.
	_body_base_scale = segment_template.get_node("Body").scale
	_hinge_base_scale = segment_template.get_node("Hinge").scale

	tip.scale = Vector2.ONE * visual_scale
	_build_segment_pool()
	_current_start_deg = idle_curl_start_deg
	_current_end_deg = idle_curl_end_deg
	_current_angles = _build_curl_angles(_current_start_deg, _current_end_deg, idle_segment_count)
	if Engine.is_editor_hint():
		# В редакторе (сцена открыта, игра НЕ запущена) щупальцу не нужны таймеры смены
		# позы, вес оружия и т.п. — только сама дуга, чтобы её было видно и удобно крутить.
		return
	weapon_sprite.visible = false
	weapon_sprite.z_index = -1
	_schedule_next_pose_change()

## Строит массив углов (в радианах, формат "относительно Vector2.DOWN", см. _update_chain)
## для idle-позы: первый сегмент смотрит под start_deg (экранный угол), последний — под
## end_deg, промежуточные — плавно между ними по ease-кривой idle_curl_curve.
## Зеркалирование право/лево делается не здесь, а выбором других start_deg/end_deg
## (см. _pick_new_idle_pose) — так переход между сторонами можно твинить напрямую как два
## числа, без рассинхронизации отдельных сегментов.
## ИСПРАВЛЕНО: раньше t шёл в lerp линейно, что даёт кривизну ИДЕАЛЬНОЙ окружности —
## именно равномерная круговая кривизна и читается как "бублик"/кольцо. Теперь t сначала
## возводится в степень idle_curl_curve (ease-in): у основания (маленькие i) угол почти не
## меняется — щупальце идёт почти прямо от тела, — и только у кончика (i ближе к концу)
## угол резко доворачивается. Силуэт получается как у гибкого хлыста/щупальца с закрученным
## кончиком, а не как ровный сегмент окружности.
##
## НОВОЕ (2 правки формы):
## 1) Второй по счёту сегмент дуги (индекс 1 в промежуточном массиве) выбрасывается —
##    сама кривая (все t, все углы) считается как прежде на полное idle_segment_count точек,
##    и только ПОСЛЕ этого одна средняя точка убирается. Изгиб дуги в целом не меняется —
##    меняется только количество физических звеньев, которое его показывает.
## 2) Последняя (видимая) точка дуги доворачивается не до полного end_deg, а только на долю
##    idle_last_segment_curl_t от пути start_deg -> end_deg — кончик развёрнут заметно наружу
##    относительно прежнего сильно закрученного положения, при этом форма дуги ДО последнего
##    сегмента не меняется.
func _build_curl_angles(start_deg: float, end_deg: float, count: int) -> Array:
	var result: Array = []
	var curve_power: float = _safe_curve_power()
	for i in range(count):
		var t = float(i) / float(max(count - 1, 1))
		var t_eased = pow(t, curve_power)
		var screen_angle_deg = lerp(start_deg, end_deg, t_eased)
		result.append(deg_to_rad(screen_angle_deg - 90.0))

	# Убираем второй по счёту сегмент (индекс 1) из готовой дуги. Кривизна не пересчитывается —
	# просто одно промежуточное звено выпадает из цепочки, изгиб сохраняется остальными точками.
	if result.size() > 2:
		result.remove_at(1)

	# Разворачиваем последний видимый сегмент чуть наружу: вместо жёсткой посадки на end_deg
	# берём промежуточную точку между start_deg и end_deg (доля idle_last_segment_curl_t).
	if result.size() > 0:
		var outward_screen_deg = lerp(start_deg, end_deg, idle_last_segment_curl_t)
		result[result.size() - 1] = deg_to_rad(outward_screen_deg - 90.0)

	return result

## Защита от ошибки "Invalid type in utility function pow(). Cannot convert argument 2 from
## Nil to float". Причина этой ошибки — НЕ баг в логике выше, а типичный артефакт Godot: при
## добавлении нового @export-поля (idle_curl_curve) в скрипт, который уже используется в
## открытой/сохранённой сцене, в .tscn может остаться "битый" override этого свойства как
## null (например, если поле в инспекторе на миг осталось пустым при сохранении). Такой
## override применяется через рефлексию при загрузке сцены В ОБХОД обычной проверки типов,
## поэтому даже у typed-переменной (: float) может на практике оказаться Nil, пока сцена не
## пересохранена. typeof() ниже проверяет это на уровне Variant, а не через "== null"
## (которое для typed float ничего бы не поймало), и в этом случае просто откатывается на 1.0
## (обычный линейный лерп без ease) вместо падения.
## ПОСТОЯННОЕ ИСПРАВЛЕНИЕ на стороне сцены (сделать один раз): открой сцену с этим узлом,
## найди в инспекторе поле "Idle Curl Curve" — если оно выглядит пустым/сброшенным, введи
## туда 1.7 (или своё значение) руками и сохрани сцену (Ctrl+S). После одного такого
## сохранения override починится и ошибка больше не появится, даже без этой защиты в коде.
func _safe_curve_power() -> float:
	if typeof(idle_curl_curve) != TYPE_FLOAT and typeof(idle_curl_curve) != TYPE_INT:
		return 1.0
	var v: float = float(idle_curl_curve)
	if not is_finite(v) or v <= 0.0:
		return 1.0
	return v

## Дублирует SegmentTemplate pool_size раз. Текстуры, выставленные на
## SegmentTemplate/Body и SegmentTemplate/Hinge в редакторе, копируются на все дубликаты
## автоматически — трогать код для этого не нужно. Масштаб применяется тут же, поверх
## исходных _body_base_scale/_hinge_base_scale (см. комментарий у этих полей выше).
func _build_segment_pool():
	for i in range(pool_size):
		var seg = segment_template.duplicate()
		seg.visible = false
		segment_pool.add_child(seg)
		_pool_segments.append(seg)
		var body: Sprite2D = seg.get_node("Body")
		var hinge: Sprite2D = seg.get_node("Hinge")
		body.scale = _body_base_scale * visual_scale
		hinge.scale = _hinge_base_scale * visual_scale
		_pool_bodies.append(body)
		_pool_hinges.append(hinge)

## Реальная высота сегмента НА ЭКРАНЕ (в локальных координатах TentacleVisual, т.е. уже с
## учётом visual_scale и исходного _body_base_scale, но ещё без масштаба Player и без учёта
## segment_overlap). Берётся напрямую из текстуры Body — поэтому размер физически не может
## разойтись с текстурой (раньше это была ручная цифра segment_length, которую легко было
## забыть подогнать под реальный арт — 16 при текстуре 32px, отсюда и был вечный нахлёст
## сегментов). ИСПРАВЛЕНО: добавлена защита от visual_scale == 0 (раньше при таком значении
## получался render_length == 0 и деление на него в reach-ветке _update_chain приводило
## к краху).
func _get_segment_render_length() -> float:
	var body_texture: Texture2D = _pool_bodies[0].texture if _pool_bodies.size() > 0 else segment_template.get_node("Body").texture
	var raw_height = body_texture.get_height() if body_texture else 32.0
	var effective_scale_y = maxf(_body_base_scale.y * visual_scale, 0.001)
	return raw_height * effective_scale_y

func _schedule_next_pose_change():
	_next_pose_change = randf_range(idle_pose_change_min, idle_pose_change_max)
	_pose_timer = 0.0

func _process(delta):
	if Engine.is_editor_hint():
		# ЖИВОЙ ПРЕДПРОСМОТР В РЕДАКТОРЕ: каждый кадр перечитываем текущие значения
		# экспортированных полей (idle_curl_start_deg, idle_curl_end_deg, idle_segment_count,
		# idle_curl_curve, segment_overlap, visual_scale, pool_size...) и перерисовываем дугу.
		# Благодаря этому двигая ползунки в инспекторе TentacleVisual (сцена ОТКРЫТА, игру
		# запускать НЕ нужно), ты сразу видишь новую форму щупальца во вьюпорте 2D-редактора.
		_ensure_pool_matches_size()
		_current_start_deg = idle_curl_start_deg
		_current_end_deg = idle_curl_end_deg
		_current_angles = _build_curl_angles(_current_start_deg, _current_end_deg, idle_segment_count)
		_extension = 0.0
		_update_chain()
		return

	_time += delta

	_current_angles = _build_curl_angles(_current_start_deg, _current_end_deg, idle_segment_count)

	if _extension <= 0.0001:
		_pose_timer += delta
		if _pose_timer >= _next_pose_change:
			_pick_new_idle_pose()

	_update_chain()

## Только для редакторского предпросмотра: если pool_size или visual_scale поменяли прямо
## в инспекторе, пересобирает пул сегментов и/или переприменяет масштаб — без этого дуга не
## обновится, если ты меняешь именно эти два поля (остальные поля читаются каждый кадр и так).
func _ensure_pool_matches_size():
	if _pool_segments.size() != pool_size:
		for child in segment_pool.get_children():
			child.free()
		_pool_segments.clear()
		_pool_bodies.clear()
		_pool_hinges.clear()
		_build_segment_pool()
		return
	for body in _pool_bodies:
		body.scale = _body_base_scale * visual_scale
	for hinge in _pool_hinges:
		hinge.scale = _hinge_base_scale * visual_scale
	tip.scale = Vector2.ONE * visual_scale

## Переключает щупальце на зеркальную сторону (право <-> лево) и плавно твинит переход.
## Вызывается сама собой по таймеру — щупальце "живёт своей жизнью".
## КЛЮЧЕВОЕ ОТЛИЧИЕ от старой версии: твинятся ДВА ЧИСЛА (start/end градусы), а не массив
## углов по сегментам. Отражение по вертикали в экранных градусах — это 180-x, поэтому на
## середине перехода start и end оба проходят через некоторую общую точку одновременно для
## ВСЕХ сегментов разом (вся дуга на миг синхронно выпрямляется, например, в вертикаль) —
## и только потом раскрывается на другую сторону. Без рассинхронизации и излома посередине.
func _pick_new_idle_pose():
	_mirrored = not _mirrored
	var target_start = idle_curl_start_deg if not _mirrored else (180.0 - idle_curl_start_deg)
	var target_end = idle_curl_end_deg if not _mirrored else (180.0 - idle_curl_end_deg)
	_blend_to_pose(target_start, target_end)
	_schedule_next_pose_change()

func _blend_to_pose(target_start: float, target_end: float, duration: float = -1.0):
	if duration < 0.0:
		duration = idle_pose_blend_duration
	if _pose_tween and _pose_tween.is_valid():
		_pose_tween.kill()
	_pose_tween = create_tween()
	_pose_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_pose_tween.tween_property(self, "_current_start_deg", target_start, duration)
	_pose_tween.parallel().tween_property(self, "_current_end_deg", target_end, duration)

## Строит цепочку: считает направление каждого активного сегмента (в покое — из текущей
## позы + шум, при вытяжении — к цели с лёгким затухающим виляньем), затем раскладывает
## Body/Hinge по позициям и прячет неиспользуемые сегменты пула. Первый шарнир ВСЕГДА
## строго в (0,0) — это гарантирует, что база никогда не "отрывается" от точки крепления.
## Hinge показывается на каждом активном сегменте всегда (это авторский арт стыков).
func _update_chain():
	var dirs: Array = []

	if _extension <= 0.0001:
		var base_dir = Vector2.DOWN.rotated(idle_base_direction_offset + _settle_wobble)
		for i in range(_current_angles.size()):
			var jitter = _noise.get_noise_2d(float(i) * 5.0, _time * idle_jitter_speed * 10.0) * idle_jitter_amplitude
			dirs.append(base_dir.rotated(_current_angles[i] + jitter))
		_set_tip_animation("idle")
	else:
		var to_target := _target_local
		var dist = min(to_target.length(), max_reach)
		var target_dir = to_target.normalized() if to_target.length() > 0.001 else Vector2.DOWN
		var reach_len = dist * _extension
		var count = clamp(int(ceil(reach_len / _get_segment_render_length() / (1.0 - segment_overlap))), 0, pool_size)
		var falloff = 1.0 - _extension
		var perp = target_dir.orthogonal()
		var idle_base_dir = Vector2.DOWN.rotated(idle_base_direction_offset)
		# "Раскрутка": на старте вытяжения цепочка ещё почти повторяет позу покоя (свёрнута),
		# и только по мере роста _extension каждый сегмент разворачивается к прямому направлению
		# на цель. Без этого при extension>0 сегменты мгновенно "телепортировались" из свёрнутой
		# формы в прямую линию — здесь же щупальце видимо разматывается, как и должно быть у
		# гибкого отростка, а не жёсткой палки.
		var straighten = smoothstep(0.0, 1.0, clamp(_extension * 1.6, 0.0, 1.0))
		for i in range(count):
			var wiggle = sin(float(i) * 0.9 + _time * 3.0) * reach_wiggle_amplitude * falloff
			var reach_dir = (target_dir + perp * wiggle).normalized()
			var idle_index = min(i, _current_angles.size() - 1)
			var idle_dir = idle_base_dir.rotated(_current_angles[idle_index]) if _current_angles.size() > 0 else target_dir
			var dir: Vector2
			if idle_dir.dot(reach_dir) < -0.999:
				dir = reach_dir
			else:
				dir = idle_dir.slerp(reach_dir, straighten).normalized()
			dirs.append(dir)
		_set_tip_animation("reach")

	var pos := Vector2.ZERO
	var render_length = _get_segment_render_length()
	# Сегменты рисуются полным реальным размером текстуры (render_length), но сдвигаются
	# друг относительно друга на чуть меньшее расстояние (spacing), если segment_overlap > 0 —
	# следующий сегмент своей широкой частью перекрывает хвост предыдущего. При overlap=0
	# (по умолчанию) сегменты стыкуются впритык РОВНО по размеру текстуры — без исторического
	# бага, из-за которого шаг был вдвое меньше реального спрайта.
	var spacing = render_length * (1.0 - segment_overlap)
	for i in range(pool_size):
		var segment: Node2D = _pool_segments[i]
		var body: Sprite2D = _pool_bodies[i]
		var hinge: Sprite2D = _pool_hinges[i]
		if i < dirs.size():
			var dir: Vector2 = dirs[i]
			segment.visible = true
			segment.position = pos
			body.position = dir * (render_length * 0.5)
			body.rotation = dir.angle() + segment_rotation_offset
			hinge.position = Vector2.ZERO
			# Шарнир — твой авторский арт для стыков, а не аварийная заглушка на резкий
			# излом: показывается ВСЕГДА на каждом активном сегменте, независимо от угла.
			hinge.visible = true
			pos += dir * spacing
		else:
			segment.visible = false

	tip.position = pos
	if dirs.size() > 0:
		tip.rotation = dirs[dirs.size() - 1].angle() + segment_rotation_offset

func _set_tip_animation(anim_name: String):
	if tip.sprite_frames and tip.sprite_frames.has_animation(anim_name) and tip.animation != anim_name:
		tip.play(anim_name)

## Плавно вытягивается к глобальной позиции цели за duration секунд.
func reach_to(target_global: Vector2, duration: float = 0.25, trans := Tween.TRANS_CUBIC, ease := Tween.EASE_OUT):
	_target_local = to_local(target_global)
	_play_tip_anticipation()
	if _extension_tween and _extension_tween.is_valid():
		_extension_tween.kill()
	_extension_tween = create_tween()
	_extension_tween.set_trans(trans).set_ease(ease)
	_extension_tween.tween_property(self, "_extension", 1.0, duration)

## Плавно возвращается в состояние покоя, а затем "дожимает" небольшое затухающее
## колебание позы (см. _play_settle_wobble) — без этого щупальце останавливалось бы
## мгновенно и выглядело деревянно.
func retract(duration: float = 0.2):
	if _extension_tween and _extension_tween.is_valid():
		_extension_tween.kill()
	_extension_tween = create_tween()
	_extension_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	_extension_tween.tween_property(self, "_extension", 0.0, duration)
	_extension_tween.tween_callback(_play_settle_wobble)

## Короткое затухающее колебание позы покоя — "остаточная инерция" после того, как щупальце
## перестало тянуться. Даёт ощущение гибкого, живого материала вместо жёсткой палки.
func _play_settle_wobble(kick_deg: float = 12.0, duration: float = 0.45):
	_settle_wobble = deg_to_rad(kick_deg) * (1 if randi() % 2 == 0 else -1)
	if _wobble_tween and _wobble_tween.is_valid():
		_wobble_tween.kill()
	_wobble_tween = create_tween()
	_wobble_tween.set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
	_wobble_tween.tween_property(self, "_settle_wobble", 0.0, duration)

## Короткий "поджим" кончика перед броском вперёд (squash-and-stretch) — подготовительное
## движение, из-за которого рывок читается резче и живее, даже если сама анимация действия
## (grab/throw) на Tip ещё не готова.
func _play_tip_anticipation(strength: float = 0.3, duration: float = 0.08):
	var base_scale = Vector2.ONE * visual_scale
	tip.scale = base_scale * (1.0 - strength)
	if _anticipation_tween and _anticipation_tween.is_valid():
		_anticipation_tween.kill()
	_anticipation_tween = create_tween()
	_anticipation_tween.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_anticipation_tween.tween_property(tip, "scale", base_scale, duration)

## Пытается проиграть анимацию действия на кончике (grab/throw). Если такой анимации ещё
## нет в SpriteFrames — откатывается на простую цветовую вспышку кончика, чтобы фидбэк
## был в любом случае, даже с неполным артом.
func flash_color(color: Color, duration: float = 0.15):
	var anim_name = "grab"
	if color == COLOR_THROW:
		anim_name = "throw"

	if tip.sprite_frames and tip.sprite_frames.has_animation(anim_name):
		tip.play(anim_name)
		return

	tip.modulate = color
	if _flash_tween and _flash_tween.is_valid():
		_flash_tween.kill()
	_flash_tween = create_tween()
	_flash_tween.tween_property(tip, "modulate", Color(1, 1, 1, 1), duration)

func set_held_weapon(weapon: WeaponResource):
	if weapon == null:
		weapon_sprite.visible = false
		return
	weapon_sprite.texture = weapon.texture
	# global_scale, а не scale: цепочка вложена в Player, а у Player scale = 1.2 — global_scale
	# сам компенсирует унаследованный масштаб, размер совпадёт с оружием на полу.
	weapon_sprite.global_scale = Vector2.ONE * weapon.pickup_scale
	weapon_sprite.visible = true
